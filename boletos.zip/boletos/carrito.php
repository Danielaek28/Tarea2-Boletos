<?php
session_start();

if(isset($_POST['destino']) && isset($_POST['precio'])) {
    
    $_SESSION['carrito'][] = ["destino" => $_POST['destino'], "precio" => $_POST['precio']];
}


$boletos = isset($_SESSION['carrito']) ? $_SESSION['carrito'] : [];

?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Carrito de Compra</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <header>
        <h1>Carrito de Compra</h1>
        <nav>
            <a href="index.php">Inicio</a>
            <a href="ticket.php">Finalizar Compra</a>
        </nav>
    </header>

    <div class="carrito-container">
        <?php foreach($boletos as $boleto): ?>
            <div class="boleto">
                <h2><?php echo $boleto['destino']; ?></h2>
                <p>Precio: $<?php echo $boleto['precio']; ?></p>
            </div>
        <?php endforeach; ?>
    </div>
    
    <form action="vaciar_carrito.php" method="post">
    <button type="submit" name="vaciar">Vaciar Carrito</button>
    
</form>
</body>

</html>

