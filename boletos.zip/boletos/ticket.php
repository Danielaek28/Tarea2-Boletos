<?php
session_start();

$boletos = isset($_SESSION['carrito']) ? $_SESSION['carrito'] : [];
$total = 0;

if(isset($_POST['nombre']) && isset($_POST['email'])) {
    
    $_SESSION['registro'] = array(
        'nombre' => $_POST['nombre'],
        'email' => $_POST['email']
    );
}
?>   
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ticket de Compra</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <header>
        <h1>Ticket de Compra</h1>
    </header>
    <h2>Datos del cliente</h2>
    <?php
    if(isset($_SESSION['registro'])) {
    echo "Nombre: " . $_SESSION['registro']['nombre'] . "<br>";
    echo "Email: " . $_SESSION['registro']['email'] . "<br>";
} else {
    echo "No hay datos del cliente registrados.";
}
?> 
    <div class="ticket-container">
        <h2>Detalle de compra</h2>
        
        <ul>
            <?php foreach($boletos as $boleto): ?>
    
                <li><?php echo $boleto['destino']; ?> - Precio: $<?php echo $boleto['precio']; ?></li>
                <?php $total += $boleto['precio']; ?>
            <?php endforeach; ?>
        </ul>
        <p>Total a pagar: $<?php echo $total; ?></p>
    </div>
</body>
</html>


