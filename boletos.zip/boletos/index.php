<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Venta de Boletos </title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <header>
        <h1>Bienvenido</h1>
        <h1>Destinos Disponibles</h1>

        <nav>
            <a href="registro.php">Registrarse</a>
            <a href="carrito.php">Carrito</a>
        </nav>
    </header>

    <div class="destinos-container">
       
        <div class="destino">
            <h2>Cancun</h2>
            <p>Horario de salida: 10:00am</p>
            <p>Precio: $250</p>
            <form action="carrito.php" method="post">
                <input type="hidden" name="destino" value="Cancun">
                <input type="hidden" name="precio" value="250">
                <button type="submit">Comprar</button>
            </form>
        </div>
        <div class="destino">
            <h2>Playa del Carmen</h2>
            <p>Horario de salida: 8:00am</p>
            <p>Precio: $260</p>
            <form action="carrito.php" method="post">
                <input type="hidden" name="destino" value="Playa del Carmen">
                <input type="hidden" name="precio" value="260">
                <button type="submit">Comprar</button>
            </form>
        </div>
        <div class="destino">
            <h2>Tulum</h2>
            <p>Horario de salida: 10:00pm</p>
            <p>Precio: $260</p>
            <form action="carrito.php" method="post">
                <input type="hidden" name="destino" value="Tulum">
                <input type="hidden" name="precio" value="260">
                <button type="submit">Comprar</button>
            </form>
        </div>
        <div class="destino">
            <h2>Puebla</h2>
            <p>Horario de salida: 6:00am</p>
            <p>Precio: $860</p>
            <form action="carrito.php" method="post">
                <input type="hidden" name="destino" value="Puebla">
                <input type="hidden" name="precio" value="860">
                <button type="submit">Comprar</button>
            </form>
        </div>
        <div class="destino">
            <h2>Chiapas</h2>
            <p>Horario de salida: 5:00pm</p>
            <p>Precio: $560</p>
            <form action="carrito.php" method="post">
                <input type="hidden" name="destino" value="Chiapas">
                <input type="hidden" name="precio" value="560">
                <button type="submit">Comprar</button>
            </form>
        </div>
        <div class="destino">
            <h2>Tabasco</h2>
            <p>Horario de salida: 3:00pm</p>
            <p>Precio: $580</p>
            <form action="carrito.php" method="post">
                <input type="hidden" name="destino" value="Tabasco">
                <input type="hidden" name="precio" value="580">
                <button type="submit">Comprar</button>
            </form>
        </div>
        <div class="destino">
            <h2>Campeche</h2>
            <p>Horario de salida: 9:00am</p>
            <p>Precio: $360</p>
            <form action="carrito.php" method="post">
                <input type="hidden" name="destino" value="Campeche">
                <input type="hidden" name="precio" value="360">
                <button type="submit">Comprar</button>
            </form>
        </div>
        <div class="destino">
            <h2>Valladolid</h2>
            <p>Horario de salida: 8:00am</p>
            <p>Precio: $260</p>
            <form action="carrito.php" method="post">
                <input type="hidden" name="destino" value="Valladolid">
                <input type="hidden" name="precio" value="260">
                <button type="submit">Comprar</button>
            </form>
        </div>
        <div class="destino">
            <h2>Cancun</h2>
            <p>Horario de salida: 8:00pm</p>
            <p>Precio: $250</p>
            <form action="carrito.php" method="post">
                <input type="hidden" name="destino" value="Cancun">
                <input type="hidden" name="precio" value="250">
                <button type="submit">Comprar</button>
            </form>
        </div>
        <div class="destino">
            <h2>Villahermosa</h2>
            <p>Horario de salida: 2:00pm</p>
            <p>Precio: $660</p>
            <form action="carrito.php" method="post">
                <input type="hidden" name="destino" value="Villahermosa">
                <input type="hidden" name="precio" value="660">
                <button type="submit">Comprar</button>
            </form>
        </div>
        <div class="destino">
            <h2>Veracruz</h2>
            <p>Horario de salida: 7:00am</p>
            <p>Precio: $860</p>
            <form action="carrito.php" method="post">
                <input type="hidden" name="destino" value="Veracruz">
                <input type="hidden" name="precio" value="860">
                <button type="submit">Comprar</button>
            </form>
        </div>
        <div class="destino">
            <h2>Oaxaca</h2>
            <p>Horario de salida: 1:00pm</p>
            <p>Precio: $960</p>
            <form action="carrito.php" method="post">
                <input type="hidden" name="destino" value="Oaxaca">
                <input type="hidden" name="precio" value="960">
                <button type="submit">Comprar</button>
            </form>
        </div>
       
    </div>
</body>
</html>
